module.exports = {
modul: {
      baileys: require("@whiskeysockets/baileys"),
      chalk: require('chalk'),
      fs: require('fs'),
      util: require('util'),
      Utils: require('@whiskeysockets/baileys/lib/Utils'),
      yargs: require('yargs')
}
}